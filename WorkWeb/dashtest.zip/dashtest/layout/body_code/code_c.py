from common import *
from layout.body_code.code_common import *

# codecheck
# c_ck_df = pd.DataFrame({
#     "Module": ["Guide", "Rule", "Total"],
#     "backup": [0, 0, 0],
#     "dataconf": [0, 0, 0],
#     "media": [0, 0, 0],
#     "proxy": [0, 0, 0],
#     "vcom": [0, 0, 0],
#     "java_module": [0, 0, 0],
#     "java_tools": [0, 0, 0],
# })
# c_ck_df.index.set_names("Name", inplace=True)
# c_ck_table = dash_table.DataTable(
#     data=c_ck_df.to_dict('records'),
#     columns=[{"name": i, "id": i} for i in c_ck_df.columns],
#     page_action="none",
#     style_table={"overflowY": "auto"},
#     style_header={"backgroundColor": "white", "fontWeight": "bold", "border": "2px solid"},
#     style_cell={"textAlign": "center"},
# )

# codecheck
c_ck_x = ["backup", "dataconf", "media", "proxy", "vcom", "java_module", "java_tools"]
c_ck_y_col1 = [263, 1, 443, 1400, 66, 3289, 253]
c_ck_y_col2 = [17, 1, 13, 97, 237, 102, 5]
c_ck_y_col3 = [0, 1, 10, 4, 24, 0, 11]

c_ck_graph = dcc.Graph(
    figure={
        "data": [
            {
                "x": c_ck_x,
                "y": c_ck_y_col1,
                "type": "bar",
                "name": "Guide",
            }, {
                "x": c_ck_x,
                "y": c_ck_y_col2,
                "type": "bar",
                "name": "Rule",
            }, {
                "x": c_ck_x,
                "y": c_ck_y_col3,
                "type": "bar",
                "name": "Rule",
            },
        ],
    }
)

# cooddy
c_cd_x = ["backup", "dataconf", "media", "proxy", "vcom"]
c_cd_y_col1 = [28, 3, 17, 56, 17]
c_cd_y_col2 = [0, 0, 0, 0, 0]
c_cd_y_col3 = [0, 0, 0, 0, 0]

c_cd_graph = dcc.Graph(
    figure={
        "data": [
            {
                "x": c_cd_x,
                "y": c_cd_y_col1,
                "type": "bar",
                "name": "Guide",
            }, {
                "x": c_cd_x,
                "y": c_cd_y_col2,
                "type": "bar",
                "name": "Rule",
            },
            {
                "x": c_cd_x,
                "y": c_cd_y_col3,
                "type": "bar",
                "name": "DDD",
            },
        ],
        "layout": {
            "autosize": True,
        }
    }
)
