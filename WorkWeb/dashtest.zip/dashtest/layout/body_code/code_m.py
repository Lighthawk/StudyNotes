from common import *
from layout.body_code.code_common import *
import plotly.express as px

# dtfuzz
m_dtfuzz_bp_dispatcher_card = create_code_dtfuzz_card("BP", "dispatcher",
                                      "https://cn.bing.com/",
                                      4, 0, "67%", 0, "03-02 13:15")
m_dtfuzz_eump_video_card = create_code_dtfuzz_card("eUMP", "video",
                                      "https://cn.bing.com/",
                                      8, 0, "69%", 0, "03-12 14:20")
m_dtfuzz_eump_mswt_card = create_code_dtfuzz_card("eUMP", "mswt",
                                      "https://cn.bing.com/",
                                      5, 0, "35%", 0, "03-12 14:20")
m_dtfuzz_eump_audio_card = create_code_dtfuzz_card("eUMP", "audio",
                                      "https://cn.bing.com/",
                                      4, 0, "39%", 0, "03-12 14:20")
m_dtfuzz_eump_stream_card = create_code_dtfuzz_card("eUMP", "stream",
                                      "https://cn.bing.com/",
                                      5, 0, "72%", 0, "03-12 14:20")
m_dtfuzz_eump_ai_card = create_code_dtfuzz_card("eUMP", "ai",
                                      "https://cn.bing.com/",
                                      8, 0, "71%", 0, "03-12 14:20")
m_dtfuzz_call_call_card = create_code_dtfuzz_card("CALL", "call",
                                      "https://cn.bing.com/",
                                      "NA", "NA", "45%", 1, "03-12 14:20")
m_dtfuzz_call_ivr_card = create_code_dtfuzz_card("CALL", "ivr",
                                      "https://cn.bing.com/",
                                      "NA", "NA", "56%", 0, "03-12 14:20")
m_dtfuzz_ms_ms_card = create_code_dtfuzz_card("MS", "ms",
                                      "https://cn.bing.com/",
                                      "NA", "NA", "60%", 0, "03-12 14:20")
m_dtfuzz_xvmcu_conf_card = create_code_dtfuzz_card("XVMXU", "conf",
                                      "https://cn.bing.com/",
                                      "NA", "NA", "41%", 0, "03-12 14:20")
m_dtfuzz_xvmcu_bnrm_card = create_code_dtfuzz_card("XVMXU", "bnrm",
                                      "https://cn.bing.com/",
                                      "NA", "NA", "71%", 1, "03-12 14:20")
m_dtfuzz_xvmcu_omc_card = create_code_dtfuzz_card("XVMXU", "omc",
                                      "https://cn.bing.com/",
                                      "NA", "NA", "49%", 0, "03-12 14:20")
m_dtfuzz_bsp_bsp_card = create_code_dtfuzz_card("MCU_BSP", "bsp",
                                      "https://cn.bing.com/",
                                      "NA", "NA", "42%", 0, "03-12 14:20")
m_dtfuzz_rse_conf_card = create_code_dtfuzz_card("RSE_code", "rse_conf",
                                      "https://cn.bing.com/",
                                      "NA", "NA", "30%", 0, "03-12 14:20")


# ut
m_ut_eump_arm_card = create_code_dt_card("eUMP", "Arm",
                                      "https://cn.bing.com/",
                                      1357, 0, "100%")
m_ut_eump_x86_card = create_code_dt_card("eUMP", "X86",
                                      "https://cn.bing.com/",
                                      1538, 0, "100%")
m_ut_call_call_card = create_code_dt_card("CALL", "call",
                                       "https://cn.bing.com/",
                                       2, 0, "100%")
m_ut_xvmcu_conf_card = create_code_dt_card("XVMCU", "conf",
                                        "https://cn.bing.com/",
                                        "NA", "NA", "0%")
m_ut_xvmcu_bnrm_card = create_code_dt_card("XVMCU", "bnrm",
                                        "https://cn.bing.com/",
                                        4, 0, "100%")
m_ut_om_om_card = create_code_dt_card("OM", "om",
                                   "https://cn.bing.com/",
                                   516, 0, "100%")
m_ut_rse_bnms_card = create_code_dt_card("RSE_code", "bnms",
                                      "https://cn.bing.com/",
                                      428, 0, "100%")

# mst
m_mst_eump_arm_card = create_code_dt_card("eUMP", "ARM",
                                          "https://cn.bing.com/",
                                          91, 5, "94.8%")
m_mst_eump_x86_card = create_code_dt_card("eUMP", "X86",
                                          "https://cn.bing.com/",
                                          91, 5, "94.8%")
m_mst_eump_nv_card = create_code_dt_card("eUMP", "NV",
                                         "https://cn.bing.com/",
                                        349, 0, "100%")
m_mst_eump_video_card = create_code_dt_card("eUMP", "video",
                                            "https://cn.bing.com/",
                                            115, 1, "99.1%")

m_mst_xvmcu_conf_card = create_code_dt_card("XVMCU", "conf",
                                            "https://cn.bing.com/",
                                            5, 0, "100%")
m_mst_om_arm_card = create_code_dt_card("OM", "ARM",
                                        "https://cn.bing.com/",
                                        254, 0, "100%")
m_mst_om_mcuinstall_card = create_code_dt_card("OM", "MCU_install",
                                               "https://cn.bing.com/",
                                               1, 0, "100%")
m_mst_rse_rseinstall_card = create_code_dt_card("eUMP", "RSE_install",
                                                "https://cn.bing.com/",
                                                1, 0, "100%")


# codecheck
# m_ck_df = pd.DataFrame({
#     "Module": ["Guide", "Rule", "Total"],
#     "bp": [0, 0, 0],
#     "video": [0, 0, 0],
#     "mswt": [0, 0, 0],
#     "audio": [0, 0, 0],
#     "stream": [0, 0, 0],
#     "common": [0, 0, 0],
#     "call": [0, 0, 0],
#     "ivr": [0, 0, 0],
#     "ms": [0, 0, 0],
#     "msp": [0, 0, 0],
#     "conf3": [0, 0, 0],
#     "bnrm3": [0, 0, 0],
#     "bsp": [0, 0, 0],
#     "om": [0, 0, 0],
#     "rse_conf": [0, 0, 0],
#     "rse_trans": [0, 0, 0],
#     "rse_om": [0, 0, 0],
#     "rse_bnms": [0, 0, 0],
#     "rse_common": [0, 0, 0],
#     # "Repo": ["BP", "eUMP", "eUMP", "eUMP", "eUMP", "eUMP", "eUMP", "CALL", "CALL", "MS", "MS", "XVMCU", "XVMCU", "XVMCU"],
#     # "Module": ["bp", "video", "mswt", "mswt", "stream", "ai", "common", "call", "ivr", "ms", "msp", "conf3", "bnrm3", "omc"],
#     # "Guide": ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"],
#     # "Rule": ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"],
# })
# m_ck_df.index.set_names("Name", inplace=True)
# m_ck_table = dash_table.DataTable(
#     data=m_ck_df.to_dict('records'),
#     columns=[{"name": i, "id": i} for i in m_ck_df.columns],
#     page_action="none",
#     style_table={"overflowY": "auto"},
#     style_header={"backgroundColor": "white", "fontWeight": "bold", "border": "2px solid"},
#     style_cell={"textAlign": "center"},
# )
m_ck_x = ["bp", "video", "mswt", "mswt", "stream", "ai", "common", "call", "ivr", "ms", "msp", "conf3",
        "bnrm3", "omc", "bsp", "om", "rse_conf", "rse_trans", "rse_om", "rse_bnms", "rse_common"]
m_ck_y_col1 = [3, 4, 89, 3, 0, 0, 1, 16, 24, 0, 0, 31, 16, 4, 0, 0, 0, 1, 8, 7, 0]
m_ck_y_col2 = [0, 0, 41, 0, 0, 0, 0, 12, 1, 0, 0, 14, 2, 1, 0, 5, 0, 1, 4, 47, 0]
# m_ck_y_cols = [[3, 0], [4, 0], [89, 41], [3, 0], [0, 0], [0, 0], [1, 0], [16, 12], [24, 1], [0, 0], [0, 0],
#                [31, 14], [16, 2], [4, 1], [0, 0], [0, 5], [0, 0], [1, 1], [8, 4], [7, 47], [0, 0]]
# m_ck_fig = px.bar(m_ck_df, x="Module", y=["Guide", "Rule", "Total"], color="lifeExp")

m_ck_graph = dcc.Graph(
    figure={
        "data": [
            {
                "x": m_ck_x,
                "y": m_ck_y_col1,
                "type": "bar",
                "name": "Rule",
            }, {
                "x": m_ck_x,
                "y": m_ck_y_col2,
                "type": "bar",
                "name": "Guide",
            },
        ],
        # "layout": {
        #     "title": "CodeCheck",
        # }
    }
)


# cooddy
# m_cd_df = pd.DataFrame({
#     "Module": ["Guide", "Rule", "Total", "DDD"],
#     "bp": [0, 0, 0, 0],
#     "video": [0, 0, 0, 0],
#     "mswt": [0, 0, 0, 0],
#     "audio": [0, 0, 0, 0],
#     "stream": [0, 0, 0, 0],
#     "common": [0, 0, 0, 0],
#     "call": [0, 0, 0, 0],
#     "ivr": [0, 0, 0, 0],
#     "ms": [0, 0, 0, 0],
#     "msp": [0, 0, 0, 0],
#     "conf3": [0, 0, 0, 0],
#     "bnrm3": [0, 0, 0, 0],
#     "bsp": [0, 0, 0, 0],
#     "om": [0, 0, 0, 0],
#     "rse_conf": [0, 0, 0, 0],
#     "rse_trans": [0, 0, 0, 0],
#     "rse_om": [0, 0, 0, 0],
#     "rse_bnms": [0, 0, 0, 0],
#     "rse_common": [0, 0, 0, 0],
# })
# m_cd_df.index.set_names("Name", inplace=True)
# m_cd_table = dash_table.DataTable(
#     data=m_cd_df.to_dict('records'),
#     columns=[{"name": i, "id": i} for i in m_cd_df.columns],
#     page_action="none",
#     style_table={"overflowY": "auto"},
#     style_header={"backgroundColor": "white", "fontWeight": "bold", "border": "2px solid"},
#     style_cell={"textAlign": "center"},
# )
m_cd_x = ["bp", "video", "mswt", "mswt", "stream", "ai", "call", "ivr", "ms", "msp", "conf3",
          "bnrm3", "omc", "bsp", "om", "rse_conf"]
m_cd_y_col1 = [31, 140, 112, 15, 1, 41, 50, 0, 87, 0, 329, 30, 6, 14, 0, 2]
m_cd_y_col2 = [0, 27, 15, 8, 6, 5, 0, 0, 11, 1, 0, 13, 0, 0, 0, 0]
m_cd_y_col3 = [0, 50, 47, 24, 7, 5, 329, 0, 36, 3, 28, 11, 0, 0, 0, 25]
m_cd_y_col4 = [259, 676, 195, 413, 56, 5, 318, 231, 1, 7, 454, 59, 18, 172, 1, 0]

m_cd_graph = dcc.Graph(
    figure={
        "data": [
            {
                "x": m_cd_x,
                "y": m_cd_y_col1,
                "type": "bar",
                "name": "G1",
            }, {
                "x": m_cd_x,
                "y": m_cd_y_col2,
                "type": "bar",
                "name": "Ru1",
            }, {
                "x": m_cd_x,
                "y": m_cd_y_col3,
                "type": "bar",
                "name": "XXX",
            }, {
                "x": m_cd_x,
                "y": m_cd_y_col4,
                "type": "bar",
                "name": "DDD",
            },

        ],
        "layout": {
            # "title": "Cooddy",
            "autosize": True,
            # "width": "1000px",
        }
    }
)
