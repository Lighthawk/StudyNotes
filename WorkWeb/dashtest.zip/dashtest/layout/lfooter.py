from common import *

footer_colors = {
    'background': '#111111',
    'text': '#7FDBFF'
}

# Footer is in Dash Enterprise, so......
# footer = html.Footer(
#     "Developed by SRE Group, 2023. All Rights Reserved.",
#     style={
#         "margin": "35%",
#         "textAlign": "center",
#         "color": footer_colors["text"]
#     },
#     className="ms-2",
# )

footer = html.Div([
    dbc.Alert(
        "Developed by SRE Group, 2023. All Rights Reserved.",
        color="light",
        style={
            # "verticalAlign": "100 auto",
            # "marginBottom": "0 auto",
            "margin": "300px",
            "textAlign": "center",
            "color": "0x000000"
        },
        className="mb-0",
    )
])
# style={"verticalAlign": "middle"}

