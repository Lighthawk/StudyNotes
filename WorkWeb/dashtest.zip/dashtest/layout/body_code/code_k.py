from common import *
from layout.body_code.code_common import *

# ut
k_ut_hmev_card = create_code_dt_card("HMEV", "X86",
                                          "https://cn.bing.com/",
                                          "NA", "NA", "0%")
k_ut_hmea_card = create_code_dt_card("HMEA", "X86",
                                          "https://cn.bing.com/",
                                          17, 0, "100%")
# codecheck
# k_ck_df = pd.DataFrame({
#     "Module": ["Guide", "Rule", "Total"],
#     "vtop": [0, 0, 0],
#     "om": [0, 0, 0],
#     "base": [0, 0, 0],
#     "rtp": [0, 0, 0],
#     "hmev": [0, 0, 0],
#     "hmea": [0, 0, 0],
#     "opensdk": [0, 0, 0],
#     "qt": [0, 0, 0],
#     "uisdk": [0, 0, 0],
#     "tsdk": [0, 0, 0],
# })
# k_ck_df.index.set_names("Name", inplace=True)
# k_ck_table = dash_table.DataTable(
#     data=k_ck_df.to_dict('records'),
#     columns=[{"name": i, "id": i} for i in k_ck_df.columns],
#     page_action="none",
#     style_table={"overflowY": "auto"},
#     style_header={"backgroundColor": "white", "fontWeight": "bold", "border": "2px solid"},
#     style_cell={"textAlign": "center"},
# )

# codecheck
k_ck_x = ["vtop", "om", "base", "rtp", "hmev", "hmea", "opensdk", "qt", "uisdk", "tsdk"]
k_ck_y_col1 = [2, 7, 36, 0, 35, 10, 24, 133, 23, 631]
k_ck_y_col2 = [30, 0, 0, 106, 0, 0, 0, 0, 0, 4]
k_ck_y_col3 = [0, 0, 0, 0, 0, 0, 0, 7, 1, 46]

k_ck_graph = dcc.Graph(
    figure={
        "data": [
            {
                "x": k_ck_x,
                "y": k_ck_y_col1,
                "type": "bar",
                "name": "Rule",
            }, {
                "x": k_ck_x,
                "y": k_ck_y_col2,
                "type": "bar",
                "name": "Guide",
            }, {
                "x": k_ck_x,
                "y": k_ck_y_col3,
                "type": "bar",
                "name": "Gx",
            },
        ],
    }
)

# cooddy
k_cd_x = ["vtop", "om", "base", "rtp", "hmev", "hmea", "opensdk", "qt", "uisdk", "tsdk"]
k_cd_y_col1 = [11, 25, 8, 13, 14, 36, 13, 42, 5, 107]
k_cd_y_col2 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
k_cd_y_col3 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

k_cd_graph = dcc.Graph(
    figure={
        "data": [
            {
                "x": k_cd_x,
                "y": k_cd_y_col1,
                "type": "bar",
                "name": "Guide",
            }, {
                "x": k_cd_x,
                "y": k_cd_y_col2,
                "type": "bar",
                "name": "Rule",
            },
            {
                "x": k_cd_x,
                "y": k_cd_y_col3,
                "type": "bar",
                "name": "Gx",
            },
        ],
        "layout": {
            "autosize": True,
        }
    }
)
