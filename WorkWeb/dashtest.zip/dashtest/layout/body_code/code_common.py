from common import *


def set_code_split_line(name):
    ret = html.Div([
        # dbc.Placeholder(color="white", className="me-1 mt-1", style={"width": "90%"}),
        # dbc.Alert(name, color="light"),
        html.Hr(style={"width": "90%"}),
        # html.Br(),
        html.H4(name),
    ])
    # ret = dbc.Alert(name, color="light")
    return ret


def create_code_dt_card(header, name, link,
                        oks, wrongs, precision):
    dt_status = html.Span([
        # dbc.Badge(name, color="primary", className="border me-1"),
        dbc.Badge(str(oks), color="white", text_color="success", className="border me-1"),
        dbc.Badge(str(wrongs), color="white", text_color="danger", className="border me-1"),
        dbc.Badge(str(precision), color="white", text_color="info", className="border me-1"),
        # dbc.Badge("Link", color="white", text_color="dark", className="border me-1", href=link),
    ])

    ret = dbc.Card([
        # dbc.CardHeader(
        #     dbc.Row([
        #         dbc.Col(html.H6(header, className="card-title"), style={"width": "auto"}),
        #         dbc.Col(dbc.Badge(name, color="primary", className="border me-1"), style={"width": "auto"}),
        #     ]),
        #     # header
        # ),
        dbc.CardHeader(
            [
                html.H6([header, dbc.Badge(name, text_color="primary", color="light", className="border me-1", pill=True, href=link)]),
            ],
        ),
        dbc.CardBody([
            # html.H6(name, className="card-subtitle"),
            dt_status
        ]),
        # dbc.CardFooter(
        #     # dbc.CardLink("Link", href=link),
        #     dbc.Button("Link", outline=True, href=link, className="me-1", size="sm"),
        # ),
        ],
        className="mt-3",
        style={"width": "11rem"},
    )
    return ret


def create_code_dtfuzz_card(header, name, link,
                        oks, wrongs, precision, asanreport, time):
    dt_status = html.Span([
        # dbc.Badge(name, color="primary", className="border me-1"),
        dbc.Badge(str(oks), color="white", text_color="success", className="border me-1"),
        dbc.Badge(str(wrongs), color="white", text_color="danger", className="border me-1"),
        dbc.Badge(str(precision + " ↓"), color="white", text_color="info", className="border me-1"),
        dbc.Badge("Asan: " + str(asanreport), color="white", text_color="secondary", className="border me-1"),
        # dbc.Badge("Link", color="white", text_color="dark", className="border me-1", href=link),
        dbc.Badge(time, text_color="warning", color="white", className="border me-1", pill=True),

    ])

    ret = dbc.Card([
        # dbc.CardHeader(
        #     dbc.Row([
        #         dbc.Col(html.H6(header, className="card-title"), style={"width": "auto"}),
        #         dbc.Col(dbc.Badge(name, color="primary", className="border me-1"), style={"width": "auto"}),
        #     ]),
        #     # header
        # ),
        dbc.CardHeader(
            [
                # dbc.Button([
                # # html.H6([
                #     header + " / " + name,
                #     dbc.Badge(name, text_color="primary", color="light", className="border me-1", pill=True, href=link),
                # ]),
                dbc.Button(header + " / " + name, outline=True, color="primary", className="me-1", size="sm", href=link),
            ],
        ),
        dbc.CardBody([
            # html.H6(name, className="card-subtitle"),
            dt_status,
        ]),
        # dbc.CardFooter(
        #     dbc.Badge(time, text_color="warning", color="0x000008", className="me-1", pill=True),
        #
        #     # html.P(time, className="me-1"),
        #     # dbc.CardLink("Link", href=link),
        #     # dbc.Button("Link", outline=True, href=link, className="me-1", size="sm"),
        # ),
        ],
        className="mt-3",
        style={"width": "15rem"},
    )
    return ret
