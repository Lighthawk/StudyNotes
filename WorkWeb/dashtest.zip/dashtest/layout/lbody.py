from common import *
from layout.body_code.code_tabs import code_tabs

nav = dbc.Nav(
    [
        dbc.NavItem(dbc.NavLink("Statistics", active=True, href="/code")),
        # dbc.NavItem(dbc.NavLink("Media Center", active=True, href="#")),
        # dbc.NavItem(dbc.NavLink("Product", active=True, href="#")),
        # dbc.NavItem(dbc.NavLink("DTS", active=True, href="#")),
        # dbc.NavItem(dbc.NavLink("Specials", active=True, href="#")),
    ],
    vertical="md",
)

code_body = dbc.Container(
    [
        dbc.Row([
            dbc.Col([
                nav,
            ], md=2),
            dbc.Col([
                code_tabs,
                # html.H2("Notice..."),
                # html.P("www"),
                # dbc.Button("View details", color="secondary")
            ]),
            # dbc.Col([
            #     html.H2("Graph"),
            #     dcc.Graph(
            #         figure={
            #             "data": [{"x": [1, 3, 4], "y": [2, 7, 5]}]
            #         }
            #     ),
            # ], md=7)
        ]),
    ]
)
