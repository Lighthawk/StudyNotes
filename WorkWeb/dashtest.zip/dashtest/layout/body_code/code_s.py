from common import *
from layout.body_code.code_common import *

# mst
s_mst_all_card = create_code_dt_card("All", "X86",
                                          "https://cn.bing.com/",
                                          10, 1, "90%")

# codecheck
# s_ck_df = pd.DataFrame({
#     "Module": ["Guide", "Rule", "Total"],
#     "web": [0, 0, 0],
#     "fileserver": [0, 0, 0],
#     "failover": [0, 0, 0],
#     "terminalmanage": [0, 0, 0],
#     "onlineconference": [0, 0, 0],
#     "httpproxy": [0, 0, 0],
#     "eua": [0, 0, 0],
#     "conference": [0, 0, 0],
#     "maintain": [0, 0, 0],
#     "common": [0, 0, 0],
# })
# s_ck_df.index.set_names("Name", inplace=True)
# s_ck_table = dash_table.DataTable(
#     data=s_ck_df.to_dict('records'),
#     columns=[{"name": i, "id": i} for i in s_ck_df.columns],
#     page_action="none",
#     style_table={"overflowY": "auto"},
#     style_header={"backgroundColor": "white", "fontWeight": "bold", "border": "2px solid"},
#     style_cell={"textAlign": "center"},
# )
# codecheck
s_ck_x = ["web", "fileserver", "failover", "terminalmanage", "onlineconference", "httpproxy", "eua", "conference", "maintain", "common"]
s_ck_y_col1 = [8, 0, 0, 0, 0, 0, 0, 0, 0, 0]
s_ck_y_col2 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
s_ck_y_col3 = [8, 0, 17, 0, 0, 0, 1, 0, 0, 1]

s_ck_graph = dcc.Graph(
    figure={
        "data": [
            {
                "x": s_ck_x,
                "y": s_ck_y_col1,
                "type": "bar",
                "name": "Guide",
            }, {
                "x": s_ck_x,
                "y": s_ck_y_col2,
                "type": "bar",
                "name": "Rule",
            }, {
                "x": s_ck_x,
                "y": s_ck_y_col3,
                "type": "bar",
                "name": "Rule",
            },
        ],
        "layout": {
            "autosize": True,
        }
    }
)

