from common import *
from layout.lnavbar import navbar
from layout.lbody import code_body
from layout.lfooter import footer

app = Dash(
    __name__,
    external_stylesheets=[dbc.themes.SPACELAB, dbc.icons.BOOTSTRAP],
    use_pages=True,
    pages_folder="",
)

code_layout = html.Div(
    [
        navbar,
        code_body,
        footer
    ]
)

product_layout = html.Div([
    navbar,
    footer
])

app.layout = html.Div([
    html.Div([
        html.Div([
            dcc.Link(
                f"{page['name']} - {page['path']}", href=page["relative_path"]
            )
        ])
        for page in dash.page_registry.values()
    ]),
    dash.page_container,
])

dash.register_page("home", path="/", layout=code_layout)
dash.register_page("code", path="/code", layout=code_layout)
dash.register_page("product", path="/product", layout=product_layout)


# @app.callback(
#     Output("navbar-collapse", "is_open"),
#     [Input("navbar-toggler", "n_clicks")],
#     [State("navbar-collapse", "is_open")],
# )
# def toggle_navbar_collapse(n, is_open):
#     if n:
#         return not is_open
#     return is_open

