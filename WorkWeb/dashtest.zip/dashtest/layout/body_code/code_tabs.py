from common import *
from layout.body_code.code_common import set_code_split_line

from layout.body_code.code_m import *
from layout.body_code.code_s import *
from layout.body_code.code_c import *
from layout.body_code.code_k import *

m_code_tab = dbc.Row([
    set_code_split_line("DTFuzz"),
    # html.Div(dbc.Placeholder("DTFuzz", color="warning", className="me-1 mt-1 w-100")),
    dbc.Row([
        dbc.Col(m_dtfuzz_bp_dispatcher_card, width="auto"),
        dbc.Col(m_dtfuzz_eump_video_card, width="auto"),
        dbc.Col(m_dtfuzz_eump_mswt_card, width="auto"),
        dbc.Col(m_dtfuzz_eump_audio_card, width="auto"),
        dbc.Col(m_dtfuzz_eump_stream_card, width="auto"),
        dbc.Col(m_dtfuzz_eump_ai_card, width="auto"),
        dbc.Col(m_dtfuzz_call_call_card, width="auto"),
        dbc.Col(m_dtfuzz_call_ivr_card, width="auto"),
        dbc.Col(m_dtfuzz_ms_ms_card, width="auto"),
        dbc.Col(m_dtfuzz_xvmcu_conf_card, width="auto"),
        dbc.Col(m_dtfuzz_xvmcu_bnrm_card, width="auto"),
        dbc.Col(m_dtfuzz_xvmcu_omc_card, width="auto"),
        dbc.Col(m_dtfuzz_bsp_bsp_card, width="auto"),
        dbc.Col(m_dtfuzz_rse_conf_card, width="auto"),
    ]),
    set_code_split_line("UT"),
    # html.Hr(),
    # html.Div(dbc.Placeholder("UT", color="warning", className="me-1 mt-1 w-100")),
    dbc.Row([
        dbc.Col(m_ut_eump_arm_card, width="auto"),
        dbc.Col(m_ut_eump_x86_card, width="auto"),
        dbc.Col(m_ut_call_call_card, width="auto"),
        dbc.Col(m_ut_xvmcu_conf_card, width="auto"),
        dbc.Col(m_ut_xvmcu_bnrm_card, width="auto"),
        dbc.Col(m_ut_om_om_card, width="auto"),
        dbc.Col(m_ut_rse_bnms_card, width="auto"),
    ]),
    set_code_split_line("MST"),
    # html.Hr(),
    # html.Div(dbc.Placeholder("MST", color="warning", className="me-1 mt-1 w-100")),
    dbc.Row([
        dbc.Col(m_mst_eump_arm_card, width="auto"),
        dbc.Col(m_mst_eump_x86_card, width="auto"),
        dbc.Col(m_mst_eump_nv_card, width="auto"),
        dbc.Col(m_mst_eump_video_card, width="auto"),
        dbc.Col(m_mst_xvmcu_conf_card, width="auto"),
        dbc.Col(m_mst_om_arm_card, width="auto"),
        dbc.Col(m_mst_om_mcuinstall_card, width="auto"),
        dbc.Col(m_mst_rse_rseinstall_card, width="auto"),
    ]),
    set_code_split_line("CodeCheck"),
    # html.Hr(),
    # html.Div(dbc.Placeholder("CodeCheck", color="warning", className="me-1 mt-1 w-100")),
    dbc.Row([
        # dbc.Col(m_ck_table, width="auto"),
        dbc.Col(m_ck_graph, width="auto"),
    ]),
    set_code_split_line("Cooddy"),
    # html.Hr(),
    # html.Div(dbc.Placeholder("Cooddy", color="warning", className="me-1 mt-1 w-100")),
    dbc.Row([
        # dbc.Col(m_cd_table, width="auto"),
        dbc.Col(m_cd_graph, width="auto"),
    ])
])

s_code_tab = dbc.Row([
    # html.Hr(),
    # html.Div(dbc.Placeholder("MST", color="warning", className="me-1 mt-1 w-100")),
    set_code_split_line("MST"),
    dbc.Row([
        dbc.Col(s_mst_all_card, width="auto"),
    ]),
    # html.Hr(),
    # html.Div(dbc.Placeholder("CodeCheck", color="warning", className="me-1 mt-1 w-100")),
    set_code_split_line("CodeCheck"),
    dbc.Row([
        # dbc.Col(s_ck_table, width="auto"),
        dbc.Col(s_ck_graph, width="auto"),
    ]),
])

c_code_tab = dbc.Card([
    # html.Div(dbc.Placeholder("CodeCheck", color="warning", className="me-1 mt-1 w-100")),
    set_code_split_line("CodeCheck"),
    dbc.Row([
        dbc.Col(c_ck_graph, width="auto"),
    ]),
    set_code_split_line("Cooddy"),
    dbc.Row([
        dbc.Col(c_cd_graph, width="auto"),
    ]),
])

k_code_tab = dbc.Row([
    # html.Hr(),
    # html.Div(dbc.Placeholder("MST", color="warning", className="me-1 mt-1 w-100")),
    set_code_split_line("MST"),
    dbc.Row([
        dbc.Col(k_ut_hmev_card, width="auto"),
        dbc.Col(k_ut_hmea_card, width="auto"),
    ]),
    # html.Hr(),
    # html.Div(dbc.Placeholder("CodeCheck", color="warning", className="me-1 mt-1 w-100")),
    set_code_split_line("CodeCheck"),
    dbc.Row([
        dbc.Col(k_ck_graph, width="auto"),
    ]),
    set_code_split_line("Cooddy"),
    dbc.Row([
        dbc.Col(k_cd_graph, width="auto"),
    ]),
])

code_tabs = dbc.Tabs([
    dbc.Tab(m_code_tab, label="mmm"),
    dbc.Tab(s_code_tab, label="sss"),
    dbc.Tab(c_code_tab, label="ccc"),
    dbc.Tab(k_code_tab, label="kkk"),
])
