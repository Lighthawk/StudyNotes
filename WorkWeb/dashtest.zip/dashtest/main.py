from layout import lapp


if __name__ == '__main__':
    lapp.app.run_server(debug=True)
